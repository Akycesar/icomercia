<style>
.btn-product{
	width: 100%;
}
</style>
<div class="container">
    <div class="row">
    	<div class="col-md-12">
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Contabilidad</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $450.000</label><br><label>A: $35.000 x M</label></h4>
							</div>
						</div>
						<p>Libros, balances, Remuneraciones, Conciliaciones</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Control Asistencia</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $250.000</label><br><label>A: $10.000 x M</label></h4>
							</div>
						</div>
						<p>Captura de fotos, sin biométrico</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product"> Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            <div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Facturacion</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $300.000</label><br><label>A: $15.000 x M</label></h4>
							</div>
						</div>
						<p>Control de facturas, emision</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product">Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            
        </div> 

	</div>
</div>

<div class="container">
    <div class="row">
    	<div class="col-md-12">
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Contabilidad</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $450.000</label><br><label>A: $35.000 x M</label></h4>
							</div>
						</div>
						<p>Libros, balances, Remuneraciones, Conciliaciones</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Control Asistencia</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $250.000</label><br><label>A: $10.000 x M</label></h4>
							</div>
						</div>
						<p>Captura de fotos, sin biométrico</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product"> Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            <div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Facturacion</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $300.000</label><br><label>A: $15.000 x M</label></h4>
							</div>
						</div>
						<p>Control de facturas, emision</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product">Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            
        </div> 

	</div>
</div>
<div class="container">
    <div class="row">
    	<div class="col-md-12">
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Contabilidad</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $450.000</label><br><label>A: $35.000 x M</label></h4>
							</div>
						</div>
						<p>Libros, balances, Remuneraciones, Conciliaciones</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Control Asistencia</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $250.000</label><br><label>A: $10.000 x M</label></h4>
							</div>
						</div>
						<p>Captura de fotos, sin biométrico</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product"> Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product"> Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            <div class="col-sm-6 col-md-4">
				<div class="thumbnail" >
					<h4 class="text-center"><span class="label label-info">Venta / Arriendo</span></h4>
					<img src="<?= base_url(); ?>application/img/sys.jpg" class="img-responsive">
					<div class="caption">
						<div class="row">
							<div class="col-md-6 col-xs-6">
								<h3>Sistema Facturacion</h3>
							</div>
							<div class="col-md-6 col-xs-6 price">
								<h4>
								<label>V: $300.000</label><br><label>A: $15.000 x M</label></h4>
							</div>
						</div>
						<p>Control de facturas, emision</p>
						<div class="row">
							<div class="col-md-6">
								<a href="producto" class="btn btn-primary btn-product">Detalle</a> 
							</div>
							<div class="col-md-6">
								<a href="#" class="btn btn-success btn-product">Comprar</a></div>
						</div>

						<p> </p>
					</div>
				</div>
			</div>
            
        </div> 

	</div>
</div>