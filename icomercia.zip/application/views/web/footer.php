<footer>
<div id="divbottom" style="position:relative;left:0px;bottom:0px;width:100%;height:70px;background-color:transparent">

<div id="redes">
<div id="rs1" title="Síguenos en Youtube"><a href="" target="_blank"><img src="<?= base_url(); ?>application/img/youtube.png"; width="30" height="30" border="0"/></a></div>
<div id="rs2" title="Síguenos en Google+"><a href="" target="_blank"><img src="<?= base_url(); ?>application/img/google+.png"; width="30" height="30" border="0"/></a></div>
<div id="rs3" title="Síguenos en Linkedin"><a href="" target="_blank"><img src="<?= base_url(); ?>application/img/linkedin.png"; width="30" height="30" border="0"/></a></div> 
<div id="rs4" title="Síguenos en Twitter"><a href="" target="_blank"><img src="<?= base_url(); ?>application/img/twitter.png"; width="30" height="30" border="0"/></a></div>  
<div id="rs5" title="Síguenos en Facebook"><a href="" target="_blank"><img src="<?= base_url(); ?>application/img/facebook.png"; width="30" height="30" border="0" /></a></div>
<div id="rs6"><a href="" target="_blank"></a></div>  
</div>

<div id="icomercia">Icomercia 2016 © Copyright - Todos los derechos reservados</div>
<div id="logoemp"><img src="<?= base_url(); ?>application/img/logoemp.png" width="150" height="55" /></div>
</div>
</div>
</body>
</html>
</footer>